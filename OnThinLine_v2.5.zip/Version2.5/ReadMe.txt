On Thin Line - v2.5
Author: Yu(Lotus) Li

Updates:
1) Fix the bug: after losing the game, timeScale becomes 0.1.
2) Add keyboard&mouse control.
3) According to 2), slightly modified the menu and instruction texts.
(Trust me. Be good to yourself and go get an XBox controller.)

Previous Versions Features:
v2.0:
1) Menu.

v1.0:
1) The game.

Introduction of the Game:
On Thin Line is created for the Ludam Dare 41st event. The theme is "Combine Two Incompatible Genres". Here I try to combine three genres: Runner, Rythm and Adventure.
The core thought of On Thin Line is that: all arts are connected; and they are all about human life. In On Thin Line I try to tell a story in both the music and the game narrative. And I think it works well, not perfectly though.
It took me 3 days to make the v1.0, and a few days more to update it to v2.5. Not much time, but I seriously love this game.

If you have tried to play it, you may find it is very difficult -- it's designed so. Life is never easy, man. If you have finally beaten it, you may find you're tricked -- it's designed so, again. Life doesn't give you what you want. It only provides limited choices, while it takes you everything to have a chance to choose among them. If you tried your best but still not able to "win", take it easy. It is just an ugly (really) CG in the end. You won't regret missing it.

Tips: 
1) A controller will make your life much easier. 
2) I know the final fighting is beautiful, but don't get distracted from playing your own role.

Contact:
yul4@andrew.cmu.edu <--- let's discuss games
https://lotusli.itch.io/on-thin-line
https://ldjam.com/events/ludum-dare/41/on-thin-line
yuli.io <--- listen to my music

Software:
Unity3D
Sibelius
Logic Pro X
Microsoft Paint

Copyright @ Yu(Lotus) Li 2018
